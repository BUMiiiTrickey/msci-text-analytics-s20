pos = neg = ""
txt=open("/Users/iris/Desktop/pos.txt", "r")
pos=txt.read()
txt1=open("/Users/iris/Desktop/neg.txt", "r")
neg=txt1.read()
pos += "\n"
pos += neg 
with open ('file3.txt', 'w') as fp: 
    fp.write(pos) 
    
review=open('file3.txt','r')
no_punctuation_documents = []
import string
for i in review:
  no_punctuation_documents.append(i.translate(str.maketrans('','', '!"#$%&()*+/:;<=>@[\\]^`{|}~\t\n')))

reviews = []
for i in no_punctuation_documents:
  reviews.append(i.split(' '))


import csv
with open('assignment1.txt','w')as s:
    writer=csv.writer(s,delimiter=' ')
    writer.writerows(reviews)

with open('out.csv','w')as q:
    writer=csv .writer(q)
    writer.writerows(reviews)
